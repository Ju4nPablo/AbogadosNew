/**
 * Created by xaipo on 3/15/2018.
 */
'use strict'

module.exports = {
    url: 'mongodb://localhost:27017/angell',
    key: 'abogados',
    database: 'mongodb://localhost:27017/'
};